#!/usr/bin/env python3
"""
Demo validation script that shows how to use the interactive validation
Enhanced version with multi-level navigation: prefix -> data selection -> validation
"""

import pandas as pd
import re
from datetime import datetime
from collections import Counter, defaultdict
from nautilus_validation.config import ConfigManager
from nautilus_validation.connectors import SpacesConnector, DatabaseConnector
from nautilus_validation.validators import ValidationEngine

def convert_date_to_yymmdd_format(date_str):
    """
    Convert date from YYYY-MM-DD format to YYMMDD integer format
    Used for querying the MySQL database which stores dates as YYMMDD
    """
    if isinstance(date_str, (int, float)):
        return int(date_str)  # Already in numeric format

    try:
        if isinstance(date_str, str):
            # Parse YYYY-MM-DD format
            if '-' in date_str and len(date_str) == 10:
                year, month, day = date_str.split('-')
                yy = year[-2:]  # Take last 2 digits
                return int(f"{yy}{month}{day}")

            # Try to parse other formats
            date_obj = datetime.strptime(date_str, '%Y-%m-%d')
            yy = date_obj.strftime('%y')
            mm = date_obj.strftime('%m')
            dd = date_obj.strftime('%d')
            return int(f"{yy}{mm}{dd}")

    except Exception as e:
        print(f"DEBUG: Could not convert date '{date_str}': {e}")
        return None

    return None

def get_date_range_for_query(dates_found):
    """
    Get min and max dates in YYMMDD format for database query
    """
    if not dates_found:
        return None, None

    converted_dates = []
    for date_val in dates_found:
        converted = convert_date_to_yymmdd_format(date_val)
        if converted:
            converted_dates.append(converted)

    if converted_dates:
        return min(converted_dates), max(converted_dates)
    return None, None

def extract_datetime_from_parquet(df):
    """
    Extract date and time columns from Parquet DataFrame
    Handles various datetime formats and column names
    """
    print("Extracting datetime information from Parquet data...")

    df_with_datetime = df.copy()

    # Check if we already have separate date and time columns
    if 'date' in df.columns and 'time' in df.columns:
        print("  Found existing date and time columns")
        return df_with_datetime

    # Look for datetime column
    datetime_cols = [col for col in df.columns
                    if any(keyword in col.lower() for keyword in ['datetime', 'timestamp', 'date_time'])]

    if datetime_cols:
        datetime_col = datetime_cols[0]
        print(f"  Found datetime column: {datetime_col}")

        try:
            # Convert to datetime if not already
            if df_with_datetime[datetime_col].dtype == 'object':
                df_with_datetime[datetime_col] = pd.to_datetime(df_with_datetime[datetime_col])

            # Extract date and time components
            df_with_datetime['date'] = df_with_datetime[datetime_col].dt.strftime('%y%m%d').astype(int)
            df_with_datetime['time'] = df_with_datetime[datetime_col].dt.hour * 10000 + \
                                     df_with_datetime[datetime_col].dt.minute * 100 + \
                                     df_with_datetime[datetime_col].dt.second

            print(f"  Extracted date and time from {datetime_col}")
            return df_with_datetime

        except Exception as e:
            print(f"  Error extracting datetime: {e}")

    # Look for other potential time columns
    time_cols = [col for col in df.columns
                if any(keyword in col.lower() for keyword in ['time', 'timestamp']) and col not in datetime_cols]

    if time_cols:
        print(f"  Found potential time columns: {time_cols}")
        # We might need to make assumptions about date from filename or context
        # For now, let's return as-is and let the validation handle it

    print("  Could not extract date/time, returning original DataFrame")
    return df_with_datetime

def normalize_dataframe_dtypes(source_df, target_df):
    """
    Normalize data types between Parquet and MySQL DataFrames
    This addresses the data type mismatches during validation
    """
    print("Normalizing data types between datasets...")

    # Make copies to avoid modifying original data
    source_normalized = source_df.copy()
    target_normalized = target_df.copy()

    # Try to extract datetime from source (Parquet) data first
    source_normalized = extract_datetime_from_parquet(source_normalized)

    # Common columns that need type alignment
    common_columns = set(source_normalized.columns) & set(target_normalized.columns)

    for col in common_columns:
        # Convert numeric columns to be consistent
        if col in ['open', 'high', 'low', 'close', 'volume', 'oi', 'coi']:
            try:
                # Convert both to float64 for comparison
                source_normalized[col] = pd.to_numeric(source_normalized[col], errors='coerce')
                target_normalized[col] = pd.to_numeric(target_normalized[col], errors='coerce')
                print(f"  Normalized {col} to numeric")
            except Exception as e:
                print(f"  Warning: Could not normalize {col}: {e}")

        # Handle date/time columns
        elif col in ['date', 'time']:
            try:
                # Convert both to int64 for comparison
                source_normalized[col] = pd.to_numeric(source_normalized[col], errors='coerce').astype('Int64')
                target_normalized[col] = pd.to_numeric(target_normalized[col], errors='coerce').astype('Int64')
                print(f"  Normalized {col} to integer")
            except Exception as e:
                print(f"  Warning: Could not normalize {col}: {e}")

        # Handle symbol column
        elif col == 'symbol':
            try:
                # Convert both to string and uppercase
                source_normalized[col] = source_normalized[col].astype(str).str.upper()
                target_normalized[col] = target_normalized[col].astype(str).str.upper()
                print(f"  Normalized {col} to uppercase string")
            except Exception as e:
                print(f"  Warning: Could not normalize {col}: {e}")

    print(f"Normalization complete")
    return source_normalized, target_normalized

def validate_ohlc_values_by_datetime(source_df, target_df, tolerance_pct=0.01):
    """
    Validate OHLC values by matching on date and time
    This checks if OHLC values match between Digital Ocean and MySQL data
    """
    print(f"\nPerforming OHLC value comparison by date/time with {tolerance_pct*100}% tolerance...")

    # Check if required columns exist
    required_cols = ['date', 'time', 'open', 'high', 'low', 'close']
    source_cols = set(source_df.columns)
    target_cols = set(target_df.columns)

    missing_source = set(required_cols) - source_cols
    missing_target = set(required_cols) - target_cols

    if missing_source:
        print(f"  Missing OHLC columns in source: {missing_source}")
        print(f"  Available source columns: {sorted(source_cols)}")
        return None
    if missing_target:
        print(f"  Missing OHLC columns in target: {missing_target}")
        return None

    try:
        # Create composite key for joining
        source_df['datetime_key'] = source_df['date'].astype(str) + '_' + source_df['time'].astype(str)
        target_df['datetime_key'] = target_df['date'].astype(str) + '_' + target_df['time'].astype(str)

        # Merge datasets on date+time
        merged = pd.merge(
            source_df[['datetime_key', 'open', 'high', 'low', 'close']],
            target_df[['datetime_key', 'open', 'high', 'low', 'close']],
            on='datetime_key',
            suffixes=('_source', '_target'),
            how='inner'
        )

        if merged.empty:
            print("  WARNING: No matching date/time records found between datasets")
            return None

        print(f"  Found {len(merged)} matching date/time records")

        # Compare OHLC values
        ohlc_cols = ['open', 'high', 'low', 'close']
        comparison_results = {}

        for col in ohlc_cols:
            source_col = f"{col}_source"
            target_col = f"{col}_target"

            if source_col in merged.columns and target_col in merged.columns:
                source_vals = merged[source_col]
                target_vals = merged[target_col]

                # Calculate absolute and percentage differences
                abs_diff = abs(source_vals - target_vals)
                pct_diff = (abs_diff / target_vals.replace(0, 1)) * 100  # Avoid division by zero

                # Count matches within tolerance
                matches = pct_diff <= tolerance_pct
                matches_count = matches.sum()
                total_count = len(merged)
                match_pct = (matches_count / total_count) * 100 if total_count > 0 else 0

                comparison_results[col] = {
                    'total_comparisons': total_count,
                    'matches_within_tolerance': matches_count,
                    'match_percentage': match_pct,
                    'avg_abs_difference': abs_diff.mean(),
                    'max_abs_difference': abs_diff.max(),
                    'avg_pct_difference': pct_diff.mean(),
                    'max_pct_difference': pct_diff.max()
                }

                print(f"    {col.upper()}: {matches_count}/{total_count} matches ({match_pct:.1f}%)")

                if not matches.all():
                    # Show some mismatches for debugging
                    mismatch_indices = pct_diff > tolerance_pct
                    if mismatch_indices.any():
                        worst_mismatch = pct_diff[mismatch_indices].idxmax()
                        print(f"      Worst {col} mismatch: Source={source_vals.iloc[worst_mismatch]}, Target={target_vals.iloc[worst_mismatch]} (diff={pct_diff.iloc[worst_mismatch]:.2f}%)")

        return comparison_results

    except Exception as e:
        print(f"  ERROR in OHLC comparison: {e}")
        import traceback
        traceback.print_exc()
        return None

def validate_ohlc_values_simple(source_df, target_df, tolerance_pct=0.01):
    """
    Simple OHLC validation without requiring date/time matching
    This compares overall OHLC value distributions
    """
    print(f"\nPerforming simple OHLC value comparison with {tolerance_pct*100}% tolerance...")

    # Check if OHLC columns exist
    ohlc_cols = ['open', 'high', 'low', 'close']
    source_cols = set(source_df.columns)
    target_cols = set(target_df.columns)

    available_ohlc = [col for col in ohlc_cols if col in source_cols and col in target_cols]

    if not available_ohlc:
        print("  No OHLC columns available for comparison")
        return None

    print(f"  Available OHLC columns: {available_ohlc}")

    try:
        comparison_results = {}

        for col in available_ohlc:
            source_vals = pd.to_numeric(source_df[col], errors='coerce').dropna()
            target_vals = pd.to_numeric(target_df[col], errors='coerce').dropna()

            if len(source_vals) == 0 or len(target_vals) == 0:
                print(f"    {col.upper()}: No valid data for comparison")
                continue

            # Compare basic statistics
            source_mean = source_vals.mean()
            target_mean = target_vals.mean()
            source_std = source_vals.std()
            target_std = target_vals.std()

            # Calculate percentage difference in means
            mean_diff_pct = abs(source_mean - target_mean) / target_mean * 100 if target_mean != 0 else 0

            # Count values within tolerance (using matched samples if same length)
            if len(source_vals) == len(target_vals):
                pct_diffs = abs(source_vals - target_vals) / target_vals * 100
                matches = (pct_diffs <= tolerance_pct).sum()
                total_comparisons = len(pct_diffs)
                match_pct = (matches / total_comparisons) * 100
            else:
                # For different lengths, compare means within tolerance
                match_pct = 100 if mean_diff_pct <= tolerance_pct else 0
                total_comparisons = min(len(source_vals), len(target_vals))
                matches = int(total_comparisons * match_pct / 100)

            comparison_results[col] = {
                'total_comparisons': total_comparisons,
                'matches_within_tolerance': matches,
                'match_percentage': match_pct,
                'source_mean': source_mean,
                'target_mean': target_mean,
                'mean_diff_pct': mean_diff_pct,
                'source_std': source_std,
                'target_std': target_std,
                'source_count': len(source_vals),
                'target_count': len(target_vals)
            }

            status = "PASS" if mean_diff_pct <= tolerance_pct else "WARN" if mean_diff_pct <= tolerance_pct * 2 else "FAIL"
            print(f"    {col.upper()}: {status} - Mean diff: {mean_diff_pct:.2f}% (Source: {source_mean:.2f}, Target: {target_mean:.2f})")

        return comparison_results

    except Exception as e:
        print(f"  ERROR in simple OHLC comparison: {e}")
        import traceback
        traceback.print_exc()
        return None

def extract_symbol_from_parquet(df):
    """
    Extract symbol from parquet DataFrame content
    """
    # Try common column names that might contain symbol
    symbol_columns = ['symbol', 'instrument', 'ticker', 'code']

    for col in symbol_columns:
        if col in df.columns and not df[col].empty:
            unique_symbols = df[col].dropna().unique()
            if len(unique_symbols) > 0:
                return str(unique_symbols[0]).upper()

    # Try to extract from other columns if no symbol column found
    for col in df.columns:
        if df[col].dtype == 'object':
            unique_vals = df[col].dropna().unique()
            # Look for values that might be symbols (uppercase letters, dots, dashes)
            for val in unique_vals[:5]:  # Check first few values
                if isinstance(val, str) and any(c.isalpha() for c in val):
                    # Check if it looks like a symbol (contains uppercase letters and maybe dots/dashes)
                    if any(c.isupper() for c in val):
                        return val.upper()

    return None

def extract_base_symbol_from_option(symbol_with_numbers):
    """
    Extract the base symbol from an option symbol that contains numbers, dates, and strikes
    Example: AARTIIND25JAN24500 -> AARTIIND
    """
    import re

    # Pattern 1: Match consecutive letters at the start (most reliable)
    pattern = r'^([A-Z]+)'
    match = re.match(pattern, symbol_with_numbers)
    if match:
        base_symbol = match.group(1)
        print(f"DEBUG: Extracted base symbol using pattern: '{base_symbol}'")
        return base_symbol

    # Pattern 2: Extract letters until first digit
    letters_part = ''
    for char in symbol_with_numbers:
        if char.isalpha():
            letters_part += char
        else:
            break
    if letters_part:
        print(f"DEBUG: Extracted base symbol using letter extraction: '{letters_part}'")
        return letters_part

    # Pattern 3: Fallback - split at first digit
    for i, char in enumerate(symbol_with_numbers):
        if char.isdigit():
            base_symbol = symbol_with_numbers[:i]
            if base_symbol:
                print(f"DEBUG: Extracted base symbol using digit detection: '{base_symbol}'")
                return base_symbol

    # If all else fails, return original
    print(f"DEBUG: No pattern matched, using original symbol: '{symbol_with_numbers}'")
    return symbol_with_numbers

def extract_symbol_from_filepath(filepath):
    """
    Extract symbol from file path when content extraction fails
    """
    path_parts = filepath.split('/')

    print(f"DEBUG: Extracting symbol from filepath: {filepath}")
    print(f"DEBUG: Path parts: {path_parts}")

    # Look for symbol-like parts in the path
    for part in path_parts:
        part_upper = part.upper()
        print(f"DEBUG: Checking part: {part}")

        # Check for various patterns
        if any(keyword in part_upper for keyword in ['NSE', 'BSE', 'FUTURE', 'INDEX', 'MINUTE', 'TICK']):
            # Extract the base symbol with enhanced logic
            symbol_part = part.split('-NSE')[0] if '-NSE' in part.upper() else part

            # Handle option symbols (like BANKNIFTY18SEP2448200PE)
            if 'NIFTY' in symbol_part or 'BANKNIFTY' in symbol_part or 'FINNIFTY' in symbol_part:
                # Extract base NIFTY symbol
                if 'BANKNIFTY' in symbol_part:
                    symbol = 'BANKNIFTY'
                    print(f"DEBUG: Found BANKNIFTY option symbol")
                    return symbol
                elif 'FINNIFTY' in symbol_part:
                    symbol = 'FINNIFTY'
                    print(f"DEBUG: Found FINNIFTY option symbol")
                    return symbol
                elif 'NIFTY' in symbol_part:
                    symbol = 'NIFTY'
                    print(f"DEBUG: Found NIFTY option symbol")
                    return symbol
                else:
                    symbol_part = symbol_part.split('.')[0] if '.' in symbol_part else symbol_part
                    print(f"DEBUG: Found other NIFTY-related symbol: {symbol_part}")
                    return symbol_part
            else:
                # Regular symbol extraction
                symbol_part = symbol_part.split('.')[0] if '.' in symbol_part else symbol_part
                if symbol_part and len(symbol_part) > 2:
                    print(f"DEBUG: Found regular symbol: {symbol_part}")
                    return symbol_part

    # Fallback - look for directories that might be symbols
    for part in path_parts:
        part_upper = part.upper()
        if any(keyword in part_upper for keyword in ['CRUDE', 'OIL', 'NIFTY', 'BANK', 'FINNIFTY']):
            print(f"DEBUG: Found keyword-based symbol: {part}")
            return part_upper

        # Check for known symbols directly
        if part_upper in ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'SENSEX']:
            print(f"DEBUG: Found exact match symbol: {part}")
            return part_upper

    print(f"DEBUG: No symbol found in filepath")
    return None

def parse_parquet_filename(filename, df=None):
    """
    Parse parquet filename to extract symbol, date, and expiry information
    """
    # Remove path and extension
    basename = filename.split('/')[-1].replace('.parquet', '')

    # Pattern 1: Timestamp-based filenames
    timestamp_pattern = r'^(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{9}Z)_(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{9}Z)$'
    timestamp_match = re.match(timestamp_pattern, basename)

    if timestamp_match:
        start_timestamp, end_timestamp = timestamp_match.groups()

        # Extract date from timestamp
        try:
            date_obj = datetime.strptime(start_timestamp.split('T')[0], '%Y-%m-%d')
            formatted_date = date_obj.strftime('%Y-%m-%d')
        except:
            formatted_date = start_timestamp.split('T')[0]

        # Try to get symbol from parquet content if DataFrame is provided
        symbol = None
        if df is not None:
            symbol = extract_symbol_from_parquet(df)

        # If no symbol found in content, try to extract from file path
        if not symbol:
            symbol = extract_symbol_from_filepath(filename)

        # Fallback to generic naming if still not found
        if not symbol:
            symbol = 'UNKNOWN'

        return {
            'symbol': symbol,
            'date': formatted_date,
            'expiry': None,
            'original_filename': filename,
            'start_time': start_timestamp,
            'end_time': end_timestamp
        }

    # Pattern 2: Other formats
    symbol = extract_symbol_from_filepath(filename)
    if not symbol:
        # Last resort - extract from filename
        parts = basename.split('_')[:1]
        symbol = parts[0].upper() if parts else 'UNKNOWN'

    return {
        'symbol': symbol,
        'date': None,
        'expiry': None,
        'original_filename': filename
    }

def determine_mysql_table(symbol, file_path):
    """
    Determine MySQL table name based on symbol and file path
    Maps exchange-format symbols to database table naming convention
    """
    # Clean the symbol - remove exchange-specific suffixes
    clean_symbol = symbol.upper().strip()

    # Remove exchange and data source suffixes
    suffixes_to_remove = [
        '.NSE-1-MINUTE-LAST-EXTERNAL',
        '.NSE-1-TICK-LAST-EXTERNAL',
        '-NSE-1-MINUTE-LAST-EXTERNAL',
        '-NSE-1-TICK-LAST-EXTERNAL',
        '.NSE-1-MINUTE-LAST',
        '.NSE-1-TICK-LAST',
        '-NSE-1-MINUTE-LAST',
        '-NSE-1-TICK-LAST'
    ]

    for suffix in suffixes_to_remove:
        if clean_symbol.endswith(suffix):
            clean_symbol = clean_symbol[:-len(suffix)]

    # Handle special cases first - direct mapping to known tables
    special_mappings = {
        'NIFTY': 'nifty_future',
        'BANKNIFTY': 'banknifty_future',
        'FINNIFTY': 'finnifty_future',
        'SENSEX': 'sensex_future',
        'BANKEX': 'bankex_future',
        'CRUDEOIL': 'crudeoil_future',
        'CRUDEOIL-I': 'crudeoil_future',
        'CRUDE': 'crudeoil_future',
        'OIL': 'crudeoil_future',
        'SILVER': 'silver_future',
        'SILVERM': 'silverm_future',
        'COPPER': 'copper_future',
        'GOLD': 'gold_future',
        'GOLDM': 'goldm_future',
        'ZINC': 'zinc_future',
        'LEAD': 'lead_future',
        'NATURALGAS': 'naturalgas_future',
        'ALUMINIUM': 'aluminium_future'
    }

    # Check special mappings first
    for key, value in special_mappings.items():
        if key in clean_symbol or clean_symbol == key:
            return value

    # Check for option symbols - these have priority!
    table_type = 'future'  # Default
    base_symbol = clean_symbol

    # Option detection patterns
    if clean_symbol.endswith('CE'):
        # Call Option European
        table_type = 'call'
        # Remove the CE suffix to get base symbol
        base_symbol = clean_symbol[:-2]
        print(f"DEBUG: Detected CALL option - base symbol before cleanup: {base_symbol}")

        # Extract base symbol for options (remove digits, dates, strikes)
        base_symbol = extract_base_symbol_from_option(base_symbol)
        print(f"DEBUG: Final base symbol for CALL option: {base_symbol}")

    elif clean_symbol.endswith('PE'):
        # Put Option European
        table_type = 'put'
        # Remove the PE suffix to get base symbol
        base_symbol = clean_symbol[:-2]
        print(f"DEBUG: Detected PUT option - base symbol before cleanup: {base_symbol}")

        # Extract base symbol for options (remove digits, dates, strikes)
        base_symbol = extract_base_symbol_from_option(base_symbol)
        print(f"DEBUG: Final base symbol for PUT option: {base_symbol}")

    elif clean_symbol.endswith('CA'):
        # Call Option American
        table_type = 'call'
        base_symbol = clean_symbol[:-2]
        print(f"DEBUG: Detected CALL option (American) - base symbol: {base_symbol}")
    elif clean_symbol.endswith('PA'):
        # Put Option American
        table_type = 'put'
        base_symbol = clean_symbol[:-2]
        print(f"DEBUG: Detected PUT option (American) - base symbol: {base_symbol}")

    # Extract base symbol from complex names (for non-options or if option detection failed)
    if table_type == 'future':  # Only do this for non-options
        # Split by common separators
        separators = ['-', '.', '_']
        for sep in separators:
            if sep in base_symbol:
                parts = base_symbol.split(sep)
                # Take the first part that looks like a symbol (contains letters)
                for part in parts:
                    if any(c.isalpha() for c in part):
                        base_symbol = part
                        break

    # Clean the base symbol
    base_symbol = base_symbol.strip()

    # Handle numeric prefixes and special cases
    if base_symbol.startswith('3I'):
        # Handle 3IINFOTECH specifically
        if 'INFOTECH' in base_symbol:
            return '3iinfotech_future'
        else:
            base_symbol = base_symbol.replace('3I', '3i')

    # Check file path for additional context about data type
    file_path_lower = file_path.lower()
    if table_type == 'future':  # Only check path for non-options
        if any(indicator in file_path_lower for indicator in ['option', 'call', 'put']):
            # Double-check option detection from file path
            if 'call' in file_path_lower:
                table_type = 'call'
            elif 'put' in file_path_lower:
                table_type = 'put'
        elif any(indicator in file_path_lower for indicator in ['1-minute', 'min', 'minute']):
            # Could be cash or future, default to future for trading data
            table_type = 'future'
        elif 'tick' in file_path_lower:
            table_type = 'future'
        elif 'cash' in file_path_lower:
            table_type = 'cash'

    # Common stock/index pattern detection
    if base_symbol and len(base_symbol) > 2 and table_type == 'future':
        # Check if it's likely a stock (ends with common stock patterns)
        if any(base_symbol.endswith(suffix) for suffix in ['LTD', 'LIMITED', 'CORP', 'IND', 'INFRA']):
            table_type = 'cash'  # Use cash for stocks
        elif base_symbol in ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'SENSEX']:
            table_type = 'future'  # Use future for indices

    # Remove any remaining special characters except common symbol characters
    import re
    base_symbol = re.sub(r'[^A-Z0-9]', '', base_symbol)

    # Final table name construction
    table_name = f"{base_symbol.lower()}_{table_type}"

    print(f"DEBUG: Final mapping - Symbol: {symbol}, Base: {base_symbol}, Type: {table_type}, Table: {table_name}")

    return table_name

def list_prefixes_in_nautilas_data(bucket):
    """List all prefixes inside nautilas-data directory"""
    print(f"\n{'='*60}")
    print("DISCOVERING AVAILABLE PREFIXES")
    print(f"{'='*60}")
    print(f"Scanning: {bucket}/nautilas-data/")

    try:
        # Load config and initialize connector
        config = ConfigManager('config.yaml')
        do_config = config.get_digital_ocean_config()
        do_config['bucket_name'] = bucket
        spaces = SpacesConnector(do_config)

        # Get all objects in nautilas-data
        all_objects = spaces.client.list_objects_v2(
            Bucket=bucket,
            Prefix='nautilas-data/',
            MaxKeys=2000,
            Delimiter='/'
        )

        prefixes = []
        if 'CommonPrefixes' in all_objects:
            for prefix_obj in all_objects['CommonPrefixes']:
                prefix = prefix_obj['Prefix']
                # Remove the 'nautilas-data/' part and trailing slash
                clean_prefix = prefix.replace('nautilas-data/', '').rstrip('/')
                if clean_prefix:  # Skip empty prefix
                    prefixes.append(clean_prefix)

        if prefixes:
            print(f"Found {len(prefixes)} prefixes:")
            print("-" * 60)

            for i, prefix in enumerate(prefixes, 1):
                print(f"{i:2d}. {prefix}")

            return prefixes
        else:
            print("No prefixes found inside nautilas-data/")
            # Let's try without delimiter to see what's actually there
            all_objects_no_delim = spaces.client.list_objects_v2(
                Bucket=bucket,
                Prefix='nautilas-data/',
                MaxKeys=50
            )

            if 'Contents' in all_objects_no_delim:
                print("\nDirect listing of first few items in nautilas-data/:")
                for i, obj in enumerate(all_objects_no_delim['Contents'][:10], 1):
                    print(f"{i:2d}. {obj['Key']}")

            return None

    except Exception as e:
        print(f"Error listing prefixes: {e}")
        import traceback
        traceback.print_exc()
        return None

def get_prefix_selection(prefixes):
    """Get user selection of which prefix to explore"""
    print("\n" + "="*60)
    print("SELECT PREFIX TO EXPLORE")
    print("="*60)

    while True:
        try:
            selection = input(f"\nEnter the number of the prefix to explore (1-{len(prefixes)}, or 'q' to quit): ").strip()

            if selection.lower() == 'q':
                return None

            if not selection:
                print("Please enter a valid number")
                continue

            selection_num = int(selection)

            if 1 <= selection_num <= len(prefixes):
                selected_prefix = prefixes[selection_num - 1]
                print(f"\nSelected: {selected_prefix}")
                return selected_prefix
            else:
                print(f"Please enter a number between 1 and {len(prefixes)}")

        except ValueError:
            print("Please enter a valid number")

def list_available_data(bucket, prefix):
    """List all available data groups in the specified prefix"""
    print(f"\n{'='*60}")
    print("DISCOVERING AVAILABLE DATA")
    print(f"{'='*60}")
    print(f"Scanning: {bucket}/nautilas-data/{prefix}")

    try:
        # Load config and initialize connector
        config = ConfigManager('config.yaml')
        do_config = config.get_digital_ocean_config()
        do_config['bucket_name'] = bucket
        spaces = SpacesConnector(do_config)

        # Get all files in the prefix
        full_prefix = f"nautilas-data/{prefix}/"
        all_objects = spaces.client.list_objects_v2(
            Bucket=bucket,
            Prefix=full_prefix,
            MaxKeys=2000
        )

        files = [obj['Key'] for obj in all_objects.get('Contents', [])]
        print(f"Found {len(files)} files in {full_prefix}")

        if not files:
            print("No files found in the specified prefix")
            return None

        # Group files by symbol/instrument
        data_groups = {}

        for file in files:
            if '.parquet' in file.lower():
                print(f"DEBUG: Processing file: {file}")
                # Extract symbol from file path
                path_parts = file.split('/')
                symbol = None

                print(f"DEBUG: Path parts: {path_parts}")

                # Look for symbol-like parts in the path
                for part in path_parts:
                    print(f"DEBUG: Checking path part: {part}")
                    part_upper = part.upper()
                    if any(keyword in part_upper for keyword in ['NSE', 'BSE', 'FUTURE', 'INDEX', 'MINUTE', 'TICK', 'LAST', 'EXTERNAL']):
                        # Extract the base symbol with enhanced logic
                        symbol_part = part.split('-NSE')[0] if '-NSE' in part.upper() else part

                        # Handle option symbols (like BANKNIFTY18SEP2448200PE)
                        if 'NIFTY' in symbol_part or 'BANKNIFTY' in symbol_part or 'FINNIFTY' in symbol_part:
                            # Extract base NIFTY symbol
                            if 'BANKNIFTY' in symbol_part:
                                symbol = 'BANKNIFTY'
                                print(f"DEBUG: Found BANKNIFTY option symbol")
                            elif 'FINNIFTY' in symbol_part:
                                symbol = 'FINNIFTY'
                                print(f"DEBUG: Found FINNIFTY option symbol")
                            elif 'NIFTY' in symbol_part:
                                symbol = 'NIFTY'
                                print(f"DEBUG: Found NIFTY option symbol")
                            else:
                                symbol = symbol_part.split('.')[0] if '.' in symbol_part else symbol_part
                                print(f"DEBUG: Found other NIFTY-related symbol: {symbol}")
                        else:
                            # Regular symbol extraction
                            symbol = symbol_part.split('.')[0] if '.' in symbol_part else symbol_part
                            if symbol and len(symbol) > 2:
                                print(f"DEBUG: Found regular symbol: {symbol}")
                                break

                # If still no symbol found, look for known symbols directly in path
                if not symbol:
                    for part in path_parts:
                        part_upper = part.upper()
                        if part_upper in ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'SENSEX', 'CRUDEOIL']:
                            symbol = part_upper
                            print(f"DEBUG: Found exact match symbol: {symbol}")
                            break

                # If still no symbol found, use the directory name before the timestamp files
                if not symbol:
                    print(f"DEBUG: Using fallback extraction")
                    for i, part in enumerate(path_parts[:-1]):  # Exclude filename
                        if part not in ['nautilas-data', 'data', 'bar', prefix] and len(part) > 2:
                            symbol = part
                            print(f"DEBUG: Using fallback symbol: {symbol}")
                            break

                if not symbol:
                    print(f"DEBUG: Could not extract symbol from: {file}")
                else:
                    print(f"DEBUG: Successfully extracted symbol: {symbol}")

                if symbol:
                    if symbol not in data_groups:
                        data_groups[symbol] = {
                            'files': [],
                            'date_range': set(),
                            'file_count': 0
                        }

                    data_groups[symbol]['files'].append(file)
                    data_groups[symbol]['file_count'] += 1

                    # Extract date from filename
                    filename = path_parts[-1]
                    if 'T' in filename:  # Timestamp format
                        date_part = filename.split('T')[0]
                        if date_part and len(date_part) == 10:  # YYYY-MM-DD format
                            data_groups[symbol]['date_range'].add(date_part)

        if not data_groups:
            print("No parquet files found or could not extract symbols")
            return None

        # Display available data groups
        print(f"\nFound {len(data_groups)} data groups in {prefix}:")
        print("-" * 60)

        for i, (symbol, data) in enumerate(sorted(data_groups.items()), 1):
            dates = sorted(data['date_range']) if data['date_range'] else []
            date_range = f"{dates[0]} to {dates[-1]}" if dates else "No dates found"

            print(f"{i:2d}. {symbol}")
            print(f"     Files: {data['file_count']}")
            print(f"     Date range: {date_range}")
            print(f"     Sample file: {data['files'][0].split('/')[-1]}")
            print()

        return data_groups

    except Exception as e:
        print(f"Error listing data: {e}")
        import traceback
        traceback.print_exc()
        return None

def get_data_selection(data_groups):
    """Get user selection of which data to validate"""
    print("\n" + "="*60)
    print("SELECT DATA TO VALIDATE")
    print("="*60)

    while True:
        try:
            selection = input(f"\nEnter the number of the data group to validate (1-{len(data_groups)}, or 'q' to quit): ").strip()

            if selection.lower() == 'q':
                return None

            if not selection:
                print("Please enter a valid number")
                continue

            selection_num = int(selection)

            if 1 <= selection_num <= len(data_groups):
                selected_symbols = list(sorted(data_groups.keys()))
                selected_symbol = selected_symbols[selection_num - 1]

                print(f"\nSelected: {selected_symbol}")
                print(f"Files available: {data_groups[selected_symbol]['file_count']}")

                # Ask for number of files to process
                while True:
                    num_files_input = input(f"\nNumber of files to process (max {data_groups[selected_symbol]['file_count']}, default 5): ").strip()
                    if not num_files_input:
                        num_files = min(5, data_groups[selected_symbol]['file_count'])
                        break

                    try:
                        num_files = int(num_files_input)
                        if num_files > data_groups[selected_symbol]['file_count']:
                            print(f"Only {data_groups[selected_symbol]['file_count']} files available")
                            continue
                        if num_files < 1:
                            print("Please enter at least 1")
                            continue
                        break
                    except ValueError:
                        print("Please enter a valid number")
                        continue

                return selected_symbol, data_groups[selected_symbol]['files'], num_files
            else:
                print(f"Please enter a number between 1 and {len(data_groups)}")

        except ValueError:
            print("Please enter a valid number")

def get_user_inputs():
    """Get user inputs for validation parameters"""
    print("=" * 60)
    print("NAUTILUS DATA VALIDATION SYSTEM")
    print("=" * 60)
    print("This tool validates parquet files against MySQL database")
    print("Multi-step process:")
    print("1. Choose bucket")
    print("2. Select prefix inside nautilas-data/")
    print("3. Choose data group to validate")
    print("4. Configure validation parameters")

    # Get bucket name
    bucket = input("\nEnter bucket name (default: historical-db-1min): ").strip()
    if not bucket:
        bucket = "historical-db-1min"

    # Step 1: List prefixes inside nautilas-data
    prefixes = list_prefixes_in_nautilas_data(bucket)

    if not prefixes:
        print("No prefixes found in nautilas-data. Validation cancelled.")
        return None, None, None, None, None

    # Step 2: Get prefix selection
    selected_prefix = get_prefix_selection(prefixes)

    if not selected_prefix:
        print("Prefix selection cancelled. Validation cancelled.")
        return None, None, None, None, None

    # Step 3: List available data in selected prefix
    data_groups = list_available_data(bucket, selected_prefix)

    if not data_groups:
        print(f"No data found in prefix '{selected_prefix}'. Validation cancelled.")
        return None, None, None, None, None

    # Step 4: Get data selection
    selection_result = get_data_selection(data_groups)

    if not selection_result:
        print("Data selection cancelled. Validation cancelled.")
        return None, None, None, None, None

    selected_symbol, selected_files, num_files = selection_result

    return bucket, selected_prefix, selected_symbol, selected_files, num_files

def demo_validation():
    """Demo validation with user inputs"""
    # Get user inputs
    bucket, selected_prefix, selected_symbol, selected_files, num_files = get_user_inputs()
    if not bucket or not selected_prefix or not selected_symbol:
        return False

    print(f"\n{'='*60}")
    print("VALIDATION PARAMETERS")
    print(f"{'='*60}")
    print(f"Bucket: {bucket}")
    print(f"Prefix: nautilas-data/{selected_prefix}")
    print(f"Selected symbol: {selected_symbol}")
    print(f"Files to process: {num_files}")

    confirm = input("\nProceed with validation? (y/N): ").strip().lower()
    if confirm not in ['y', 'yes']:
        print("Validation cancelled by user")
        return False

    print(f"\n{'='*60}")
    print("STARTING VALIDATION")
    print(f"{'='*60}")

    try:
        # Load configuration
        print("Loading configuration...")
        config = ConfigManager('config.yaml')

        # Initialize connectors
        print("Initializing connectors...")
        do_config = config.get_digital_ocean_config()
        do_config['bucket_name'] = bucket
        spaces = SpacesConnector(do_config)
        database = DatabaseConnector(config.get_database_config())

        # Parse filenames and determine MySQL table
        print(f"\nAnalyzing selected parquet files...")
        file_info_list = []
        symbols_found = set()
        dates_found = set()
        table = None

        for file in selected_files[:num_files]:
            print(f"Processing: {file}")
            try:
                # Read a sample of the parquet to extract symbol information
                sample_df = spaces.read_parquet_file(file)
                if sample_df.empty:
                    print(f"    Warning: Empty parquet file")
                    continue

                # Parse filename with DataFrame content for better symbol extraction
                file_info = parse_parquet_filename(file, sample_df)
                if file_info:
                    file_info['mysql_table'] = determine_mysql_table(file_info['symbol'], file)
                    file_info_list.append(file_info)
                    symbols_found.add(file_info['symbol'])
                    if file_info['date']:
                        dates_found.add(file_info['date'])
                    print(f"    -> Symbol: {file_info['symbol']}, Date: {file_info['date']}, Table: {file_info['mysql_table']}")
                    print(f"    -> Parquet rows: {len(sample_df):,}, Columns: {len(sample_df.columns)}")

                    # Use the first table as our target table
                    if not table:
                        table = file_info['mysql_table']
                else:
                    print(f"    Warning: Could not parse filename {file}")
                    continue

            except Exception as e:
                print(f"    Error reading {file}: {e}")
                continue

        if not file_info_list:
            print("Could not parse any parquet filenames")
            return False

        # Use the most common table found
        if not table:
            table_counter = Counter([fi['mysql_table'] for fi in file_info_list])
            table = table_counter.most_common(1)[0][0]

        print(f"\nAuto-detected MySQL table: {table}")
        print(f"Symbols found: {', '.join(symbols_found)}")
        if dates_found:
            print(f"Date range: {min(dates_found)} to {max(dates_found)}")

        # Read Parquet data
        print(f"\nReading parquet files for validation...")
        parquet_dfs = []
        total_rows = 0

        for file_info in file_info_list:
            file = file_info['original_filename']
            print(f"Reading file: {file}")
            try:
                df = spaces.read_parquet_file(file)
                parquet_dfs.append(df)
                file_rows = len(df)
                total_rows += file_rows
                print(f"   Read {file_rows:,} rows")

                # Check for OHLC columns
                ohlc_cols = [col for col in df.columns if col.upper() in ['OPEN', 'HIGH', 'LOW', 'CLOSE']]
                if ohlc_cols:
                    print(f"   OHLC columns found: {', '.join(ohlc_cols)}")

                # Show column names for debugging
                print(f"   Columns: {', '.join(df.columns[:10])}")  # Show first 10 columns

            except Exception as e:
                print(f"   Error reading {file}: {e}")
                continue

        if not parquet_dfs:
            print("No files were successfully read")
            return False

        source_df = pd.concat(parquet_dfs, ignore_index=True)
        print(f"\nTotal Parquet rows: {len(source_df):,}")

        # Read corresponding database data
        print(f"\nReading data from MySQL table: {table}")

        try:
            with database.engine.connect() as conn:
                # First, check table structure to see what columns are available
                print(f"Checking table structure for {table}...")
                try:
                    structure_query = f"DESCRIBE {table}"
                    structure_df = pd.read_sql_query(structure_query, conn)
                    table_columns = [row[0] for _, row in structure_df.iterrows()]
                    print(f"Table columns: {', '.join(table_columns)}")
                except:
                    # Fallback if DESCRIBE doesn't work
                    sample_query = f"SELECT * FROM {table} LIMIT 1"
                    sample_df = pd.read_sql_query(sample_query, conn)
                    table_columns = sample_df.columns.tolist()
                    print(f"Table columns (from sample): {', '.join(table_columns)}")

                # Get date range from Parquet data or parsed filenames
                date_filter = ""
                if 'date' in source_df.columns:
                    # Convert Parquet dates to YYMMDD format for database query
                    unique_dates = source_df['date'].unique()
                    yymmdd_dates = [convert_date_to_yymmdd_format(d) for d in unique_dates if d is not None]
                    if yymmdd_dates:
                        min_date = min(yymmdd_dates)
                        max_date = max(yymmdd_dates)
                        date_filter = f" WHERE date >= {min_date} AND date <= {max_date}"
                        print(f"DEBUG: Using Parquet date range: {min_date} to {max_date}")
                elif dates_found:
                    # Convert parsed dates to YYMMDD format for database query
                    min_date, max_date = get_date_range_for_query(dates_found)
                    if min_date and max_date:
                        date_filter = f" WHERE date >= {min_date} AND date <= {max_date}"
                        print(f"DEBUG: Using parsed date range: {min_date} to {max_date}")
                    else:
                        print("DEBUG: Could not convert parsed dates to YYMMDD format")
                else:
                    print("DEBUG: No date information available for filtering")

                # Add symbol filter only if table has symbol column and symbols were found
                has_symbol_column = 'symbol' in [col.lower() for col in table_columns]
                if symbols_found and has_symbol_column:
                    symbol_list = "', '".join(symbols_found)
                    if date_filter:
                        date_filter += f" AND symbol IN ('{symbol_list}')"
                    else:
                        date_filter = f" WHERE symbol IN ('{symbol_list}')"

                # Construct query with OHLC focus
                query = f"SELECT * FROM {table}{date_filter} ORDER BY date, time LIMIT {len(source_df) + 1000}"
                print(f"Query: {query[:100]}...")

                database_df = pd.read_sql_query(query, conn)
                print(f"Database rows read: {len(database_df):,}")

                # Check OHLC columns in database
                db_ohlc_cols = [col for col in database_df.columns if col.upper() in ['OPEN', 'HIGH', 'LOW', 'CLOSE']]
                if db_ohlc_cols:
                    print(f"Database OHLC columns: {', '.join(db_ohlc_cols)}")

        except Exception as e:
            print(f"Error reading database: {e}")
            print(f"Full error details:")
            import traceback
            traceback.print_exc()
            return False

        # Normalize data types between datasets to fix type mismatches
        source_df, database_df = normalize_dataframe_dtypes(source_df, database_df)

        # Show Parquet column information for debugging
        print(f"\nParquet DataFrame info:")
        print(f"  Shape: {source_df.shape}")
        print(f"  Columns: {list(source_df.columns)}")
        print(f"  Data types: {dict(source_df.dtypes)}")

        # Perform OHLC value comparison by date/time (primary method)
        ohlc_comparison_results = validate_ohlc_values_by_datetime(source_df, database_df, tolerance_pct=0.01)

        # If date/time comparison fails, try simple OHLC comparison
        if ohlc_comparison_results is None:
            print("Date/time OHLC comparison failed, trying simple OHLC comparison...")
            ohlc_comparison_results = validate_ohlc_values_simple(source_df, database_df, tolerance_pct=0.01)

        # Configure validation with OHLC focus
        print(f"\nConfiguring validation...")

        # Identify OHLC columns in both datasets
        source_ohlc = [col for col in source_df.columns if col.upper() in ['OPEN', 'HIGH', 'LOW', 'CLOSE']]
        target_ohlc = [col for col in database_df.columns if col.upper() in ['OPEN', 'HIGH', 'LOW', 'CLOSE']]

        print(f"Source OHLC columns: {source_ohlc}")
        print(f"Target OHLC columns: {target_ohlc}")

        # Check if key columns exist before proceeding with full data comparison
        key_columns = ['date', 'time']
        missing_keys = set(key_columns) - set(source_df.columns) - set(database_df.columns)
        if missing_keys:
            print(f"WARNING: Missing key columns for full comparison: {missing_keys}")
            print("Disabling full data comparison, but will run other validations")
            full_data_comparison_enabled = False
        else:
            full_data_comparison_enabled = True

        validation_config = {
            'row_count_validation': True,
            'data_integrity_validation': True,
            'full_data_comparison': full_data_comparison_enabled,
            'row_count_tolerance': 0.05,  # 5% tolerance
            'sample_size': min(10000, len(source_df), len(database_df)),
            'ohlc_validation': len(source_ohlc) > 0 and len(target_ohlc) > 0
        }

        # Run validation
        print("Running validation engine...")
        engine = ValidationEngine(validation_config)

        # Only pass key columns if they exist and full comparison is enabled
        if full_data_comparison_enabled:
            result = engine.validate(source_df, database_df, key_columns=key_columns)
        else:
            result = engine.validate(source_df, database_df)

        # Display results
        print(f"\n{'='*60}")
        print("VALIDATION RESULTS")
        print(f"{'='*60}")
        print(f"Overall Status: {result.overall_status.value}")
        print(f"Source Rows: {result.total_rows_source:,}")
        print(f"Target Rows: {result.total_rows_target:,}")
        print(f"Validations Run: {len(result.validation_results)}")
        print(f"Total Execution Time: {sum(val.execution_time for val in result.validation_results):.3f}s")

        # Display OHLC-specific validation summary
        if validation_config.get('ohlc_validation'):
            print(f"\nOHLC Validation Summary:")
            print(f"- OHLC columns validated: {len(source_ohlc)} source, {len(target_ohlc)} target")
            ohlc_validations = [v for v in result.validation_results if 'OHLC' in v.validation_type.upper()]
            for ohlc_val in ohlc_validations:
                status_symbol = "[PASS]" if ohlc_val.status.value == "PASSED" else "[FAIL]" if ohlc_val.status.value == "FAILED" else "[WARN]"
                print(f"  {status_symbol} {ohlc_val.message}")

        # Display OHLC value comparison results
        if ohlc_comparison_results:
            # Determine which type of comparison was performed
            if 'mean_diff_pct' in list(ohlc_comparison_results.values())[0]:
                print(f"\nOHLC Value Comparison (Statistical):")
                print(f"- Tolerance: 1%")
                print(f"- Method: Statistical comparison (no date/time matching available)")
                for col, metrics in ohlc_comparison_results.items():
                    mean_diff_pct = metrics['mean_diff_pct']
                    status = "PASS" if mean_diff_pct <= 1.0 else "WARN" if mean_diff_pct <= 2.0 else "FAIL"
                    status_symbol = "[PASS]" if status == "PASS" else "[WARN]" if status == "WARN" else "[FAIL]"

                    print(f"  {status_symbol} {col.upper()}: {status}")
                    print(f"     Mean difference: {mean_diff_pct:.2f}%")
                    print(f"     Source: {metrics['source_mean']:.2f} ± {metrics['source_std']:.2f} ({metrics['source_count']:,} values)")
                    print(f"     Target: {metrics['target_mean']:.2f} ± {metrics['target_std']:.2f} ({metrics['target_count']:,} values)")
            else:
                print(f"\nOHLC Value Comparison by Date/Time:")
                print(f"- Tolerance: 1%")
                for col, metrics in ohlc_comparison_results.items():
                    match_pct = metrics['match_percentage']
                    status = "PASS" if match_pct >= 95 else "WARN" if match_pct >= 80 else "FAIL"
                    status_symbol = "[PASS]" if status == "PASS" else "[WARN]" if status == "WARN" else "[FAIL]"

                    print(f"  {status_symbol} {col.upper()}: {metrics['matches_within_tolerance']:,}/{metrics['total_comparisons']:,} matches ({match_pct:.1f}%)")
                    print(f"     Avg difference: {metrics['avg_abs_difference']:.2f} ({metrics['avg_pct_difference']:.3f}%)")
                    print(f"     Max difference: {metrics['max_abs_difference']:.2f} ({metrics['max_pct_difference']:.3f}%)")
        else:
            print(f"\nOHLC Value Comparison: Not available (missing data or no matching records)")

        print(f"\n{'='*60}")
        print("DETAILED RESULTS")
        print(f"{'='*60}")

        for val_result in result.validation_results:
            status_symbol = "[PASS]" if val_result.status.value == "PASSED" else "[FAIL]" if val_result.status.value == "FAILED" else "[WARN]"
            print(f"\n{status_symbol} {val_result.validation_type.upper()}: {val_result.status.value}")
            print(f"   Message: {val_result.message}")
            print(f"   Execution time: {val_result.execution_time:.3f}s")

            if val_result.issues:
                print(f"   Issues found: {len(val_result.issues)}")
                for i, issue in enumerate(val_result.issues[:5]):  # Show first 5 issues
                    print(f"     {i+1}. {issue.issue_type}: {issue.message}")
                if len(val_result.issues) > 5:
                    print(f"     ... and {len(val_result.issues) - 5} more issues")

        # Clean up
        database.close()

        print(f"\n{'='*60}")
        if result.overall_status.value == "PASSED":
            print("VALIDATION COMPLETED SUCCESSFULLY!")
        else:
            print("VALIDATION COMPLETED WITH ISSUES!")
        print(f"{'='*60}")

        return True

    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = demo_validation()
    exit(0 if success else 1)